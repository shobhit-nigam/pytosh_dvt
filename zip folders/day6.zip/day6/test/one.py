lista = [7, 5, 6]

assert sum(lista) == 19, "should have been 18"
