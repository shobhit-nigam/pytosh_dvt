lista = [7, 5, 6]

def test_add():
    assert sum(lista) == 18, "should have been 18"

test_add()
print("everything passed neatly")
