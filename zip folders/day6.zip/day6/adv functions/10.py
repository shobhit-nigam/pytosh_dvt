
sa = ['brazil', 'peru', 'argentina', 'aruba', 'paraguay', 'chile']

lista = [ '', 0, 0.0, False, None, [], {}]
listb = ['hello', 0, 10.0, False, None, [3, 6], {}, (3, 10, 7)]

print(any(lista))
print(any(listb))
print("----")
print(all(lista))
print(all(listb))
print(all(sa))




