def red():
    print("function red")




if __name__ == "__main__":
    countries = ['brazil', 'peru', 'argentina', 'aruba', 'paraguay', 'chile']
else:
    countries = ['norway', 'finland', 'spain', 'austria', 'sweden', 'italy']
