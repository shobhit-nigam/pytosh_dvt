# for using range with start & end
# increment in form steps

lista = ['rr', 'yy', 'tt', 'll', 'ee', 'yy', 'ff', 'ss', 'yy']

for i in range(len(lista)):
    print("i =", i)
    print("lista[i] =", lista[i])
               

