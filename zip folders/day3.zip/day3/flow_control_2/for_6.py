# for with sequences (lists, sets, strings, tuple)

lista = ['rr', 'yy', 'tt', 'll', 'ee', 'yy', 'ff', 'ss', 'yy']

index = []

for val in lista:
    print("val =", val)
               

