# for using range with start & end
# increment in form steps

for i in range(3, 17, 3):
    print("i =", i)

