if age < 18:
    # code 
    pass
