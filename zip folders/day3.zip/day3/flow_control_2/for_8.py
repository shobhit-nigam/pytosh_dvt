# for (dict)

lista = ['rr', 'yy', 'tt', 'll', 'ee', 'yy', 'ff', 'ss', 'yy']

avengers = {'captain':'shield', 'hawkeye':'arrows', 'ironman':'suit'}
index = []

for x in avengers:
    print("x =", x)
               
for x in avengers:
    print("keys =", x, "values =", avengers[x])
