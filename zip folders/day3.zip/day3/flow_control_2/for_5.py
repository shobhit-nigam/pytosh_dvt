# for using range with start & end
# increment in form steps

lista = ['rr', 'yy', 'tt', 'll', 'ee', 'yy', 'ff', 'ss', 'yy']

index = []

for i in range(7, 0, -1):
    print("i =", i)
        
               

