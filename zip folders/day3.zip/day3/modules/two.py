# fetching the os module
# creating a directory

import os

print(os.mkdir('sample'))
