# fetching the date time

import datetime

d = datetime.datetime.now()

print(d)
print(d.year)
