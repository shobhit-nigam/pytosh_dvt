# fetching the time

import time 

print("hello")
time.sleep(8)
print("hi")
