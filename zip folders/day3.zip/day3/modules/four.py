# fetching the time

import os

print("hello")
os.system("pause")
print("hi")
