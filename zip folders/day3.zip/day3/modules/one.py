# fetching the os module
import os

print(os.getcwd())
