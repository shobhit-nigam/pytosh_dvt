def red():
    print("scarlet red")

def blue():
    print("cool blue")

def purple():
    print("fermented wine colour is a mix of ")
    red()
    blue()
