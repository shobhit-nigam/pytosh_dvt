# custom modules

path = '/Users/shobhit/Desktop/tsip/day3/functions'
import sys
sys.path.append(path)

import func_2

func_2.greet(100, 200, 300)

