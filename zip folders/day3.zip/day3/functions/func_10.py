# functions
# return

def funca(la, lb):
    lc = la*2 + 3*lb
    return lc

