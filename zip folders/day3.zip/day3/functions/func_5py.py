# functions
# only latest definition

def greet(ta, tb):
    print("hi")

def greet(la, lb, *lc):
    print("la =", la)
    print("lb =", lb)
    print("lc =", lc)

