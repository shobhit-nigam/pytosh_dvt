# functions

def greet():
    print("good morning")
    print("guten tag")
    print("ohayo")
