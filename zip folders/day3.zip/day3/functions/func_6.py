# functions
# variable number of arguments

def greet(la, lb, *args):
    print("la =", la)
    print("lb =", lb)
    print("args =", args)

