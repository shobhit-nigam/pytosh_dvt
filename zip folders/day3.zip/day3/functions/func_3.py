# functions
# default values

def greet(la, lb=70, lc=100):
    print("la =", la)
    print("lb =", lb)
    print("lc =", lc)

