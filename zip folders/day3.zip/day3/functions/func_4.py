# functions
# default values

def greet(la=50, lb=70, lc=100):
    print("la =", la)
    print("lb =", lb)
    print("lc =", lc)

