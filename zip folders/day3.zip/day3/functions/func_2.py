# functions

def greet(la, lb):
    print("la =", la)
    print("lb =", lb)

#greet("jj", "tt")
#greet(23, 7.8)

# error
#greet(10, 20, 30)


def greet(la, lb, lc):
    print("la =", la)
    print("lb =", lb)
    print("lb =", lc)
