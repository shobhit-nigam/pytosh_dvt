# files

# exists ?
# 

import os

print(os.path.exists("books_2.txt"))

print(os.listdir())
