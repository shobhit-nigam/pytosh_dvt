# comments 
# this is not going to be read by my system
# data declaration

ia = 23
ib = 45

ic = ia+ib

# int ia = 34;

print(ic) 
