# data types

ia = 23
ib = 45
fa = 45.78
stra = "earth"

print(type(ia))
print(type(ib))
print(type(fa))
print(type(stra)) 
