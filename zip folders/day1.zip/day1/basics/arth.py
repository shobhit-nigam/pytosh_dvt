
ia = 137
ib = 5

print("ia/ib =", ia/ib)
print("ia%ib =", ia%ib)
print("ia//ib =", ia//ib)
print("ib**3 =", ib**3)
