print("hello toshiba")


statement = "hello world"


print(statement) 
