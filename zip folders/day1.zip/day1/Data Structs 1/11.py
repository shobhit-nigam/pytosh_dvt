#  functions
#  slicing, stepping 

avengers = ['hulk', 'captain', 'ironman', 'captain', 'black widow']
dc = ['wonderwoman', 'batman', 'joker', 'aquaman']

num = [7, 9, 12, 45, 89, 3, 4, 10]

print("type of avengers = ", type(avengers))
print("type of num = ", type(num))
print(num[::3])
