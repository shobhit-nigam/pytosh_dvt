#  functions

avengers = ['hulk', 'captain', 'ironman', 'captain', 'black widow']
dc = ['wonderwoman', 'batman', 'joker', 'aquaman']

print("avengers =", avengers)
avengers.reverse()
print("avengers =", avengers)
avengers.sort()
print("avengers =", avengers)
