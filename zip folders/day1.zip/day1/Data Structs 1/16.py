#  #  functions

avengers = ['hulk', 'captain', 'ironman', 'captain', 'black widow']
dc = ['wonderwoman', 'batman', 'joker', 'aquaman']

heroes = ['shaktiman', 'asterix', 'omniman']

print("heroes = ", heroes)
# heroes.append(dc)
heroes.extend(dc)
print("heroes = ", heroes)


