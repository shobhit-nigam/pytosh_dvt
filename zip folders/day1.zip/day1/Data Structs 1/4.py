# mutable
# 
avengers = ['hulk', 'captain', 'ironman', 'captain', 'black widow']
dc = ['wonderwoman', 'batman', 'joker', 'aquaman']

print("type(avengers) =", type(avengers))
print("type(avengers[2]) =", type(avengers[2]))
print("avengers =", avengers)
print("avengers[2] =", avengers[2])
print("avengers[2][2] =", avengers[2][2])

# error code
avengers[2][2] = 'O'
#print("avengers =", avengers)

