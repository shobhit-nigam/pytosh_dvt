avengers = ['hulk', 'captain', 'ironman', 'captain', 'black widow']
dc = ['wonderwoman', 'batman', 'joker', 'aquaman']

print(type(avengers))
print(len(avengers))
print("avengers =", avengers)
print("avengers[2] =", avengers[2])
