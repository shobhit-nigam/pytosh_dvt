#  functions
#  append, insert

avengers = ['hulk', 'captain', 'ironman', 'captain', 'black widow']
dc = ['wonderwoman', 'batman', 'joker', 'aquaman']

print("avengers =", avengers)
avengers.remove('captain')
print("avengers =", avengers)
avengers.pop(0)
print("avengers =", avengers)
avengers.clear()
print("avengers =", avengers)
avengers.reverse()
print("avengers =", avengers)

