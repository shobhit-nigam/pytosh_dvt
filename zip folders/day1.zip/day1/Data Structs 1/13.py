#  
#  nesting

avengers = ['hulk', 'captain', 'ironman', 'captain', 'black widow']
dc = ['wonderwoman', 'batman', 'joker', 'aquaman']

heroes = ['shaktiman', 'asterix', 'omniman', avengers, dc]

print("heroes = ", heroes)
print("type of heroes = ", type(heroes))
#print("type of lista = ", type(lista))
#print("lista = ", lista)
