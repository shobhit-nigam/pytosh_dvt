#  functions
# 
avengers = ['hulk', 'captain', 'ironman', 'captain', 'black widow']
dc = ['wonderwoman', 'batman', 'joker', 'aquaman']

print(avengers.count('captain'))
#print("avengers =", avengers)



