#  
#  re assign
avengers = ['hulk', 'captain', 'ironman', 'captain', 'black widow']
dc = ['wonderwoman', 'batman', 'joker', 'aquaman']

print("avengers =", avengers)
avengers[0] = avengers[-1]
print("avengers =", avengers)




