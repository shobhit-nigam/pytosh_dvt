#  functions

avengers = ['hulk', 'captain', 'ironman', 'captain', 'black widow']
dc = ['wonderwoman', 'batman', 'joker', 'aquaman']

print("avengers =", avengers)
avengers.append('wanda')
print("avengers =", avengers)
avengers.insert(3, 'black panther')
print("avengers =", avengers)
