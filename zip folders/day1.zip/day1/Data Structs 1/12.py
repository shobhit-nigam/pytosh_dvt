#  functions
#  slicing, stepping 

avengers = ['hulk', 'captain', 'ironman', 'captain', 'black widow']
dc = ['wonderwoman', 'batman', 'joker', 'aquaman']

num = [7, 9, 12, 45, 89, 3, 4, 10]

lista = [33, "hi", 23.56, 10]

print("type of avengers = ", type(avengers))
print("type of lista = ", type(lista))
print("lista = ", lista)
