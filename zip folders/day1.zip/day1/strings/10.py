# functions


stra = "earth peace"    

print("stra = ", stra)
print(stra.count('e'))
print("stra.find = ", stra.rfind('e'))
