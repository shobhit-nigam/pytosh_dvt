# functions


stra = "341983"     # string (numeric string)
inta = 341983       # integer
fa = 34.89
