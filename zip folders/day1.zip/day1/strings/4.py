# index
# slice

stra = "eesalacupnamdhe"

print("stra[0:7] ", stra[0:7])
print("stra[2:9] is ", stra[2:9])
print("len of stra is ", len(stra))

# no error code
print("stra[4:20] is ", stra[4:20])
print("stra[24:50] is ", stra[24:50])


