# functions
# immutable
stra = "lucifer"

print("stra = ", stra)
print(stra.capitalize())
print("stra = ", stra)
strb = stra.capitalize()
print("strb = ", strb)
