# functions

stra = "lucifer"

print("stra = ", stra)
print(stra.upper())
print("stra = ", stra)
