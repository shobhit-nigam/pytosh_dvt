# index
# no chars, only strings

stra = "Roger"



print("type stra is ", type(stra))
print("type stra[4] is ", type(stra[4]))


strb = "carol"
