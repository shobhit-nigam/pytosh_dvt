# index
# slice & steps

stra = "eesalacupnamdhe"

print("stra[0:14:2] ", stra[0:14:2])
print("stra[::3] is ", stra[::3])
            # starts at zero, ends at end
            # step of 3
