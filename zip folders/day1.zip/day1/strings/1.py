# index

stra = "Roger"



print("stra[0] is ", stra[0])
print("stra[4] is ", stra[4])

# error code
print("stra[11] is ", stra[11])

