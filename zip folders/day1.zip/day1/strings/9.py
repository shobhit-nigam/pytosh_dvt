# functions
# immutable
stra = "lucifer"    # 3400
strb = "micheal"    # 3860

strb = stra



print("stra = ", stra)
print(stra.upper())
print("stra = ", stra)
print("strb = ", strb)
stra = stra.upper()
print("stra = ", stra)
print("strb = ", strb)
