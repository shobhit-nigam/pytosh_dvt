# form two
x, y, z = 34, "hello", ['qq', 'tt', 'uu']

print("x =", x)
print("y =", y)
print("z =", z)

