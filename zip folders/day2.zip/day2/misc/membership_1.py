# 
# operators

lista = ['aa', 'bb', 'cc', 'rr', 'yy']
avengers = {'captain':['shield', 'hammer'], 'hawkeye':'arrows', 'ironman':'suit'}
marvel = {'magneto':'metal', 'mystique':'transforms', 'ave':avengers}

print('aa' in lista)
print('oo' in lista)
print('vision' in avengers)         # searches among the keys
print('bucky' not in avengers)      # searches among the keys



