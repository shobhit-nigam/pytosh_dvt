# one form
x = y = z = 300

print("x =", x)
print("y =", y)
print("z =", z)

