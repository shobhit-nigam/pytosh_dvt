# sorted, min, max
# functions

lista = ('aa', 'bb', 'WW', 'cc', 'rr', 'yy', 'RR')
marvel = {'magneto', 'metal', 'mystique', 'transforms', 'ave'}
listb = [23, 45, 66, 89, 23.7]
tupa = ('hi', 23, 'Hello')

x = set(lista)

print("type of lista =", type(lista))
print("type of x =", type(x))

print(sorted(lista))
print(max(marvel))



