# while
#  

age = eval(input("please enter the age: "))
while age <= 18:
    print("no vaccine at age =", age)
    age = age + 1


print("mask on")



