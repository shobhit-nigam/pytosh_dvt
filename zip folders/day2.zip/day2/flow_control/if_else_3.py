# if else
# multiple elifs
# only code block gets executed
# indentation

age = 21

if age < 18:
    print("no vaccine")
    # code block
elif age >= 18 and age <45:
    print("difficult, but try to get vaccinated")
elif age > 45 and age < 60:
    print("should have been vaccinated by now")
else:
    print("senior citizens")
print("mask on")



