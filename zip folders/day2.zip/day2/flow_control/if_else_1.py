# if else 

age = 21

if age < 18:
    print("no vaccine")
    # code block
else:
    print("keep trying on cowin")



