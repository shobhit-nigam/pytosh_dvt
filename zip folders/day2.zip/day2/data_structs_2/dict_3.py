# dict
# key value
# functions, .keys() , .values()
fruits = {'citrus':['oranges', 'limes'], 'tropical':'mangoes', 'melons':['watermelons', 'rockmelons']}
avengers = {'captain':'shield', 'hawkeye':'arrows', 'ironman':'suit'}

# set
ave_two = {'captain', 'hawkeye', 'ironman'}

print("avengers =", avengers)
print("avengers.keys() =", avengers.keys())
print("avengers['ironman'] =", avengers['ironman'])



