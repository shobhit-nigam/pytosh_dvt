# dict
# key value 
fruits = {'citrus':['oranges', 'limes'], 'tropical':'mangoes', 'melons':['watermelons', 'rockmelons']}
avengers = {'captain':'shield', 'hawkeye':'arrows', 'ironman':'suit'}

# set
ave_two = {'captain', 'hawkeye', 'ironman'}

print("type of fruits =", type(fruits))



