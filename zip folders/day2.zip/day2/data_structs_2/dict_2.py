# dict
# key value 
fruits = {'citrus':['oranges', 'limes'], 'tropical':'mangoes', 'melons':['watermelons', 'rockmelons']}
avengers = {'captain':'shield', 'hawkeye':'arrows', 'ironman':'suit'}

# set
ave_two = {'captain', 'hawkeye', 'ironman'}

print("type of avengers =", type(avengers))
print("avengers =", avengers)
print("avengers['ironman'] =", avengers['ironman'])

# error
print("avengers[3] =", avengers[3])


