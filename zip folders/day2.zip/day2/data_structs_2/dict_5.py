# dict
# mutable

avengers = {'captain':['shield', 'hammer'], 'hawkeye':'arrows', 'ironman':'suit'}
marvel = {'magneto':'metal', 'mystique':'transforms', 'ave':avengers}
print("avengers =", avengers)

print("marvel =", marvel)



