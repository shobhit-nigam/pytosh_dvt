# set

fruits = {'plums', 'apples', 'oranges', 'plums', 'grapes', 'oranges', 'pears'}
baskets = {'oranges', 'melons', 'grapes', 'guavas', 'bananas'}

print("type of fruits =", type(fruits))
print("fruits =", fruits)

