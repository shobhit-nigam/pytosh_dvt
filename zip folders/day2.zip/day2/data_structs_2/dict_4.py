# dict
# mutable
fruits = {'citrus':['oranges', 'limes'], 'tropical':'mangoes', 'melons':['watermelons', 'rockmelons']}
avengers = {'captain':'shield', 'hawkeye':'arrows', 'ironman':'suit'}
print("avengers =", avengers)
avengers['thor'] = 'hammer'
avengers['captain'] = ['shield', 'hammer']
print("avengers =", avengers)



