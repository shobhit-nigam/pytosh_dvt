import json

with open("example_2.json", "r") as fj:
    dicta = json.load(fj)


