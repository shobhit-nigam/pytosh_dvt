import json

with open("example_1.json", "r") as fj:
    stra = json.load(fj)


