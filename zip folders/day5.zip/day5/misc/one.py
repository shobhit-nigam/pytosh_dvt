varx = 30
vary = 35
varz = 30
