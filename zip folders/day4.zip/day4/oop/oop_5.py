# OOP

class bank:
    cid = 23
    current_balance = 2000
    cust_name = None
    
    def funca(self):
        print("hello from funca in bank")

    def display(ttt):
        print("cid =", ttt.cid)
        print("current balance =", ttt.current_balance)
 

obja = bank()
objb = bank()

#error
obja.display()
    # bank.funcx(obja)
