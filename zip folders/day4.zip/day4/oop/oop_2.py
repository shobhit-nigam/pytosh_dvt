# OOP

class bank:
    cid = 23
    current_balance = 2000
    
    def funca(self):
        print("hello from funca in bank")

obja = bank()
objb = bank()
print(type(objb))
    
