# OOP

lista = [7, 9, 12, 20]

print(type(lista))

inta = 100

print(type(inta))
