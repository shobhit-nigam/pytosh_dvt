class A:
    data = 32
    """this function is used to perfrom
    complex calculations"""
    datb = 34

    def __init__(self):
        print("in init")

    pass


class B:
    """this function is used to perfrom
    complex calculations"""
    data = 32
    datb = 34
    pass
