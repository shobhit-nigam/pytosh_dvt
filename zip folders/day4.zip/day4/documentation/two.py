def funca():
    """this function is used to perfrom
    complex calculations"""
    print("you have called a function")
    print("hello from a")

def funcb():
    print("you have called a function")
    "this function is used to perfrom complex calculations"
    print("hello from a")


strb = '''hello
there'''

print(strb)
